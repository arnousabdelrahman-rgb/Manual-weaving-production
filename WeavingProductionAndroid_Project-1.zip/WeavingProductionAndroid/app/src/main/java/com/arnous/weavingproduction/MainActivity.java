package com.arnous.weavingproduction;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.content.Context;
import android.net.Uri;
import android.util.Base64;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NativeShare(this), "AndroidShare");
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    public static class NativeShare {
        private final Activity activity;
        NativeShare(Context c) { activity = (Activity)c; }
        @JavascriptInterface public void shareText(String text) {
            activity.runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                activity.startActivity(Intent.createChooser(send, "مشاركة إنتاج الفني"));
            });
        }
        @JavascriptInterface public void saveFile(String name, String mimeType, String base64) {
            activity.runOnUiThread(() -> {
                try {
                    File dir = new File(activity.getCacheDir(), "shared");
                    if (!dir.exists() && !dir.mkdirs()) throw new Exception("Cannot create cache directory");
                    String safeName = (name == null ? "report.txt" : name).replaceAll("[^a-zA-Z0-9._-]", "_");
                    File file = new File(dir, safeName);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                    Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", file);
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(mimeType == null || mimeType.isEmpty() ? "application/octet-stream" : mimeType.split(";")[0]);
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.putExtra(Intent.EXTRA_SUBJECT, safeName);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    activity.startActivity(Intent.createChooser(send, "حفظ أو مشاركة التقرير"));
                } catch (Exception e) {
                    Toast.makeText(activity, "تعذر تجهيز الملف للمشاركة", Toast.LENGTH_LONG).show();
                }
            });
        }
        @JavascriptInterface public void showMessage(String text) {
            activity.runOnUiThread(() -> Toast.makeText(activity, text, Toast.LENGTH_SHORT).show());
        }
    }
}
